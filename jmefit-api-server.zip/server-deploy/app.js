// SiteGround Node.js entry point
// This file serves as the main entry point for SiteGround Node.js hosting

import './index.js';

// This file simply imports the main application file
// SiteGround may look for app.js as the default entry point
